import React from "react";
import { motion } from "framer-motion";
import { Server, Shield, Cloud, Wifi, Monitor, Settings, Globe } from 'lucide-react';

const Skills = () => {
  const skills = [
    {
      icon: <Server className="h-8 w-8 mb-4 text-primary" />,
      title: "Network Administration",
      description:
        "Setting up and maintaining computer networks, including LAN, WAN, and VPN configurations.",
    },
    {
      icon: <Shield className="h-8 w-8 mb-4 text-primary" />,
      title: "Cybersecurity",
      description:
        "Implementing security measures to protect systems from threats and vulnerabilities.",
    },
    {
      icon: <Cloud className="h-8 w-8 mb-4 text-primary" />,
      title: "Cloud Computing",
      description:
        "Expertise in AWS, Azure, and Google Cloud platforms for scalable infrastructure solutions.",
    },
    {
      icon: <Globe className="h-8 w-8 mb-4 text-primary" />,
      title: "Wordpress Developer",
      description:
        "Developing and customizing WordPress themes and plugins, and managing WordPress sites.",
    },
    {
      icon: <Wifi className="h-8 w-8 mb-4 text-primary" />,
      title: "Wireless Networking",
      description:
        "Designing and implementing secure and efficient wireless network solutions.",
    },
    {
      icon: <Monitor className="h-8 w-8 mb-4 text-primary" />,
      title: "IT Support",
      description:
        "Providing technical assistance and troubleshooting for hardware and software issues.",
    },
    {
      icon: <Settings className="h-8 w-8 mb-4 text-primary" />,
      title: "System Administration",
      description:
        "Managing and maintaining Windows and Linux servers and workstations.",
    },
  ];

  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="skills" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-2">My Skills</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Here are the key technical skills and competencies I've developed
            throughout my career in IT.
          </p>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              variants={item}
              className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 text-center shadow-md skill-card"
            >
              <div className="flex justify-center">{skill.icon}</div>
              <h3 className="text-lg font-semibold mb-2">{skill.title}</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                {skill.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;