import React from "react";
import { motion } from "framer-motion";
import { Award, Calendar, GraduationCap, User } from "lucide-react";

const About = () => {
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="about" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={fadeIn}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-2">About Me</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Get to know more about my background, experience, and what drives me
            in the IT industry.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-primary/10 rounded-lg transform rotate-3"></div>
            <img 
              alt="Ahmad Rufai Shagari working on IT solutions"
              className="relative z-10 rounded-lg shadow-xl w-full"
             src="https://images.unsplash.com/photo-1489506020498-e6c1cc350f10" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-2xl font-bold mb-4 gradient-text">
              IT Professional with a Passion for Innovation
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              I am Ahmad Rufai Shagari, an IT professional with over 2 years of
              experience in designing, implementing, and maintaining IT
              solutions. My expertise spans across network administration,
              cybersecurity, cloud computing, and IT support.
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-8">
              I am passionate about leveraging technology to solve complex
              business problems and improve operational efficiency. My approach
              combines technical expertise with a strong understanding of
              business needs to deliver solutions that drive real value.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <User className="text-primary h-5 w-5" />
                <span className="text-gray-700 dark:text-gray-300">
                  Ahmad Rufai Shagari
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Calendar className="text-primary h-5 w-5" />
                <span className="text-gray-700 dark:text-gray-300">
                  2+ Years Experience
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <GraduationCap className="text-primary h-5 w-5" />
                <span className="text-gray-700 dark:text-gray-300">
                  BSc Information Technology
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Award className="text-primary h-5 w-5" />
                <span className="text-gray-700 dark:text-gray-300">
                  Certified IT Professional
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;