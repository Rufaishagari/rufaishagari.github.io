import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";

const Hero = () => {
  const scrollToContact = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      window.scrollTo({
        top: contactSection.offsetTop - 80,
        behavior: "smooth",
      });
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center hero-pattern pt-16"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 to-white/90 dark:from-gray-900/50 dark:to-gray-900/90"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="text-center max-w-3xl mx-auto"
        >
          <motion.div variants={item} className="mb-6">
            <img  
              alt="Ahmad Rufai Shagari profile photo" 
              className="w-32 h-32 rounded-full mx-auto border-4 border-white shadow-xl object-cover"
             src="https://storage.googleapis.com/hostinger-horizons-assets-prod/d23b5ca1-f871-41e9-a08a-fd06ed981966/1ecb2d68d1ae842bdc29a28e7a86f7eb.jpg" />
          </motion.div>
          
          <motion.h1
            variants={item}
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4"
          >
            Hi, I'm <span className="gradient-text">Ahmad Rufai Shagari</span>
          </motion.h1>
          
          <motion.h2
            variants={item}
            className="text-xl md:text-2xl font-medium text-gray-600 dark:text-gray-300 mb-6"
          >
            IT Professional with 2+ Years of Experience
          </motion.h2>
          
          <motion.p
            variants={item}
            className="text-gray-600 dark:text-gray-300 mb-8 text-lg"
          >
            Delivering innovative IT solutions and services with a focus on
            efficiency, security, and user experience.
          </motion.p>
          
          <motion.div
            variants={item}
            className="flex justify-center space-x-4 mb-12"
          >
            <Button
              onClick={scrollToContact}
              className="gradient-bg hover:opacity-90 transition-opacity"
            >
              Contact Me
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                const aboutSection = document.getElementById("about");
                if (aboutSection) {
                  window.scrollTo({
                    top: aboutSection.offsetTop - 80,
                    behavior: "smooth",
                  });
                }
              }}
            >
              Learn More
            </Button>
          </motion.div>
          
          <motion.div
            variants={item}
            className="flex justify-center space-x-6 mb-12"
          >
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-primary dark:text-gray-400 dark:hover:text-primary transition-colors"
              aria-label="GitHub"
            >
              <Github className="w-6 h-6" />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-primary dark:text-gray-400 dark:hover:text-primary transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-6 h-6" />
            </a>
            <a
              href="mailto:rufaishagari0707@outlook.com"
              className="text-gray-600 hover:text-primary dark:text-gray-400 dark:hover:text-primary transition-colors"
              aria-label="Email"
            >
              <Mail className="w-6 h-6" />
            </a>
          </motion.div>
        </motion.div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button
          onClick={() => {
            const aboutSection = document.getElementById("about");
            if (aboutSection) {
              window.scrollTo({
                top: aboutSection.offsetTop - 80,
                behavior: "smooth",
              });
            }
          }}
          aria-label="Scroll down"
          className="text-primary"
        >
          <ArrowDown className="w-6 h-6" />
        </button>
      </div>
    </section>
  );
};

export default Hero;