
import React from "react";
import { motion } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";
import { Button } from "@/components/ui/button";

const Projects = () => {
  const projects = [
    {
      title: "Network Security Overhaul",
      description:
        "Implemented a comprehensive security solution for a mid-sized company, including firewall configuration, intrusion detection systems, and employee security training.",
      image: "network-security",
      tags: ["Network Security", "Firewall", "IDS/IPS"],
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "Cloud Migration Project",
      description:
        "Led the migration of on-premises infrastructure to AWS cloud, resulting in 40% cost reduction and improved scalability for a retail client.",
      image: "cloud-migration",
      tags: ["AWS", "Cloud Computing", "Infrastructure"],
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "Automated Backup System",
      description:
        "Designed and implemented an automated backup solution using scripting and cloud storage, ensuring data integrity and disaster recovery capabilities.",
      image: "backup-system",
      tags: ["Automation", "Data Backup", "Scripting"],
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "IT Helpdesk Portal",
      description:
        "Developed a web-based helpdesk portal for internal IT support, streamlining ticket management and improving response times.",
      image: "helpdesk-portal",
      tags: ["Web Development", "IT Support", "UX Design"],
      links: {
        demo: "#",
        github: "#",
      },
    },
  ];

  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-2">Featured Projects</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            A selection of IT projects I've worked on that showcase my technical
            skills and problem-solving abilities.
          </p>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              variants={item}
              className="bg-gray-50 dark:bg-gray-700 rounded-lg overflow-hidden shadow-md project-card"
            >
              <div className="relative h-60 overflow-hidden">
                <img 
                  alt={`${project.title} project screenshot`}
                  className="w-full h-full object-cover"
                 src="https://images.unsplash.com/photo-1667984390553-7f439e6ae401" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <h3 className="text-white text-xl font-bold">{project.title}</h3>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    asChild
                  >
                    <a
                      href={project.links.github}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Github className="h-4 w-4" />
                      <span>Code</span>
                    </a>
                  </Button>
                  <Button
                    size="sm"
                    className="flex items-center gap-1"
                    asChild
                  >
                    <a
                      href={project.links.demo}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span>Live Demo</span>
                    </a>
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
